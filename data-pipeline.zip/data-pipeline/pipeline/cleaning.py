"""Cleaning and validation.

Everything here is driven by the :class:`~pipeline.config.SchemaSpec` for a
source. The guiding rule is that a single bad row should never kill a run:
rows that cannot be repaired are moved to a *reject* frame with a reason
attached, and the run carries on. The caller decides whether the resulting
reject ratio is acceptable.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd

from .config import FieldSpec, SchemaSpec
from .logging_setup import get_logger

log = get_logger("cleaning")

TRUE_TOKENS = {"true", "t", "yes", "y", "1", "on"}
FALSE_TOKENS = {"false", "f", "no", "n", "0", "off"}
CURRENCY_CHARS = "£$€¥₹,%  "  # includes a non-breaking space

DATE_FORMATS = [
    "%Y-%m-%d",
    "%d/%m/%Y",
    "%d-%m-%Y",
    "%m/%d/%Y",
    "%d %b %Y",
    "%d %B %Y",
    "%Y/%m/%d",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M:%S",
]

REJECT_REASON_COLUMN = "_reject_reason"
SOURCE_COLUMN = "_source"


@dataclass
class FieldStats:
    """Per-column record of what the cleaner had to do."""

    missing_in_input: int = 0
    coercion_failures: int = 0
    filled: int = 0
    out_of_range: int = 0
    not_allowed: int = 0


@dataclass
class CleanStats:
    rows_in: int = 0
    rows_out: int = 0
    rows_rejected: int = 0
    duplicates_removed: int = 0
    columns_dropped: list[str] = field(default_factory=list)
    columns_missing: list[str] = field(default_factory=list)
    fields: dict[str, FieldStats] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "rows_in": self.rows_in,
            "rows_out": self.rows_out,
            "rows_rejected": self.rows_rejected,
            "duplicates_removed": self.duplicates_removed,
            "columns_dropped": self.columns_dropped,
            "columns_missing": self.columns_missing,
            "fields": {
                name: {k: v for k, v in vars(stat).items() if v}
                for name, stat in self.fields.items()
                if any(vars(stat).values())
            },
        }

    @property
    def reject_ratio(self) -> float:
        return self.rows_rejected / self.rows_in if self.rows_in else 0.0


@dataclass
class CleanResult:
    frame: pd.DataFrame
    rejects: pd.DataFrame
    stats: CleanStats


# --------------------------------------------------------------------------
# value-level helpers
# --------------------------------------------------------------------------

def is_null(value: Any) -> bool:
    """True for None, NaN, NaT and whitespace-only strings.

    pandas silently converts a mapped ``None`` into a float ``NaN``, so an
    identity check against ``None`` is not enough: without this, ``str(nan)``
    quietly turns a missing value into the literal text "nan".
    """
    if value is None:
        return True
    if isinstance(value, float) and np.isnan(value):
        return True
    try:
        if pd.isna(value):
            return True
    except (TypeError, ValueError):
        pass
    return isinstance(value, str) and not value.strip()


def normalize_nulls(series: pd.Series, null_tokens: list[str]) -> pd.Series:
    """Replace blanks and configured placeholder strings with ``None``."""
    tokens = set(null_tokens)

    def convert(value: Any) -> Any:
        if is_null(value):
            return None
        if isinstance(value, str) and value.strip().lower() in tokens:
            return None
        return value

    return series.map(convert)


def apply_string_transforms(series: pd.Series, transforms: list[str]) -> pd.Series:
    """Apply the declared text tidy-ups in the order they were configured."""
    operations = {
        "strip": lambda s: s.strip(),
        "lower": lambda s: s.lower(),
        "upper": lambda s: s.upper(),
        "title": lambda s: s.title(),
        "collapse_spaces": lambda s: " ".join(s.split()),
        "strip_currency": lambda s: s.translate(str.maketrans("", "", CURRENCY_CHARS)).strip(),
        "digits_only": lambda s: "".join(c for c in s if c.isdigit()),
    }

    def convert(value: Any) -> Any:
        if is_null(value):
            return None
        text = str(value)
        for name in transforms:
            text = operations[name](text)
        return text or None

    return series.map(convert)


def _to_number(value: Any) -> float | None:
    """Best-effort numeric parse that tolerates currency symbols and separators."""
    if isinstance(value, bool):
        return float(value)
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return float(value)
    text = str(value).strip()
    negative = text.startswith("(") and text.endswith(")")  # accounting negatives
    if negative:
        text = text[1:-1]
    text = text.translate(str.maketrans("", "", CURRENCY_CHARS)).strip()
    if not text:
        return None
    try:
        number = float(text)
    except ValueError:
        return None
    return -number if negative else number


def coerce_series(series: pd.Series, spec: FieldSpec) -> tuple[pd.Series, pd.Series]:
    """Cast ``series`` to ``spec.type``.

    Returns the converted series plus a boolean mask marking values that were
    present but could not be converted.
    """
    present = series.notna()

    if spec.type in {"integer", "float"}:
        numbers = series.map(lambda v: None if is_null(v) else _to_number(v))
        if spec.type == "integer":
            def to_int(value: Any) -> Any:
                if is_null(value):
                    return None
                return int(round(value)) if float(value).is_integer() else None
            numbers = numbers.map(to_int)
            converted = pd.Series(
                pd.array(list(numbers), dtype="Int64"), index=series.index
            )
        else:
            converted = pd.Series(
                pd.array(list(numbers), dtype="Float64"), index=series.index
            )

    elif spec.type == "boolean":
        def to_bool(value: Any) -> Any:
            if is_null(value):
                return None
            if isinstance(value, bool):
                return value
            text = str(value).strip().lower()
            if text in TRUE_TOKENS:
                return True
            if text in FALSE_TOKENS:
                return False
            return None
        converted = pd.Series(
            pd.array(list(series.map(to_bool)), dtype="boolean"), index=series.index
        )

    elif spec.type in {"date", "datetime"}:
        converted = _coerce_datetime(series, spec)

    elif spec.type == "category":
        converted = series.map(lambda v: None if is_null(v) else str(v)).astype("category")

    else:  # string
        converted = pd.Series(
            pd.array(
                [None if is_null(v) else str(v) for v in series], dtype="string"
            ),
            index=series.index,
        )

    failed = present & converted.isna()
    return converted, failed


def _coerce_datetime(series: pd.Series, spec: FieldSpec) -> pd.Series:
    """Parse dates, trying the configured format first then common UK/ISO ones."""
    text = series.map(lambda v: None if is_null(v) else str(v).strip())
    result = pd.Series(pd.NaT, index=series.index, dtype="datetime64[ns]")
    remaining = text.notna()

    formats = ([spec.date_format] if spec.date_format else []) + DATE_FORMATS
    for fmt in formats:
        if not remaining.any():
            break
        attempt = pd.to_datetime(text[remaining], format=fmt, errors="coerce")
        matched = attempt.notna()
        if matched.any():
            result.loc[attempt.index[matched]] = attempt[matched]
            remaining.loc[attempt.index[matched]] = False

    if remaining.any():
        # Last resort: let pandas infer, day-first to suit UK-style data.
        attempt = pd.to_datetime(
            text[remaining], errors="coerce", dayfirst=True, format="mixed"
        )
        matched = attempt.notna()
        if matched.any():
            result.loc[attempt.index[matched]] = attempt[matched]

    if spec.type == "date":
        result = result.dt.normalize()
    return result


# --------------------------------------------------------------------------
# frame-level steps
# --------------------------------------------------------------------------

def _select_and_rename(
    frame: pd.DataFrame, schema: SchemaSpec, stats: CleanStats, source: str
) -> pd.DataFrame:
    out = pd.DataFrame(index=frame.index)
    for spec in schema.fields:
        if spec.input_name in frame.columns:
            out[spec.name] = frame[spec.input_name]
        else:
            stats.columns_missing.append(spec.name)
            stats.fields[spec.name].missing_in_input = len(frame)
            log.warning(
                "Source '%s': column '%s' not present in input; filling with nulls",
                source, spec.input_name,
            )
            out[spec.name] = None

    if not schema.drop_unknown_columns:
        declared = {s.input_name for s in schema.fields}
        for column in frame.columns:
            if column not in declared:
                out[column] = frame[column]
    else:
        declared = {s.input_name for s in schema.fields}
        dropped = [c for c in frame.columns if c not in declared]
        if dropped:
            stats.columns_dropped = dropped
            log.info("Source '%s': dropped undeclared column(s) %s", source, dropped)
    return out


def _fill_missing(series: pd.Series, spec: FieldSpec) -> tuple[pd.Series, int]:
    """Apply the configured fill strategy. Returns the series and how many it filled."""
    missing = series.isna()
    count = int(missing.sum())
    if not count or spec.fill == "none":
        return series, 0

    if spec.fill == "default":
        value: Any = spec.default
    elif spec.fill == "zero":
        value = 0
    elif spec.fill == "empty":
        value = ""
    elif spec.fill == "ffill":
        filled = series.ffill()
        return filled, int(count - filled.isna().sum())
    elif spec.fill in {"mean", "median"}:
        if series.notna().sum() == 0:
            log.warning("Field '%s': no values to compute %s from", spec.name, spec.fill)
            return series, 0
        value = getattr(series, spec.fill)()
        if spec.type == "integer":
            value = int(round(float(value)))
    elif spec.fill == "mode":
        modes = series.mode(dropna=True)
        if modes.empty:
            return series, 0
        value = modes.iloc[0]
    else:  # pragma: no cover - guarded by config validation
        return series, 0

    return series.fillna(value), count


def _validate(series: pd.Series, spec: FieldSpec, stat: FieldStats) -> pd.Series:
    """Return a mask of rows failing the declared constraints."""
    invalid = pd.Series(False, index=series.index)

    if spec.allowed is not None:
        allowed = set(spec.allowed)
        bad = series.notna() & ~series.isin(allowed)
        stat.not_allowed = int(bad.sum())
        invalid |= bad

    if spec.min is not None or spec.max is not None:
        numeric = pd.to_numeric(series, errors="coerce")
        bad = pd.Series(False, index=series.index)
        if spec.min is not None:
            bad |= numeric.notna() & (numeric < spec.min)
        if spec.max is not None:
            bad |= numeric.notna() & (numeric > spec.max)
        stat.out_of_range = int(bad.sum())
        invalid |= bad

    return invalid


def clean_dataset(frame: pd.DataFrame, schema: SchemaSpec, source: str) -> CleanResult:
    """Run the full clean for one source. Never raises on bad data."""
    stats = CleanStats(rows_in=len(frame))
    for spec in schema.fields:
        stats.fields[spec.name] = FieldStats()

    columns = [s.name for s in schema.fields]
    if frame.empty:
        log.warning("Source '%s': no rows to clean", source)
        empty = pd.DataFrame(columns=columns)
        return CleanResult(empty, pd.DataFrame(columns=[*columns, REJECT_REASON_COLUMN]), stats)

    working = _select_and_rename(frame, schema, stats, source)
    reasons = pd.Series([[] for _ in range(len(working))], index=working.index)

    for spec in schema.fields:
        stat = stats.fields[spec.name]
        series = normalize_nulls(working[spec.name], schema.null_tokens)

        if spec.transform:
            series = apply_string_transforms(series, spec.transform)

        series, failed = coerce_series(series, spec)
        stat.coercion_failures = int(failed.sum())
        if stat.coercion_failures:
            log.warning(
                "Source '%s': %d value(s) in '%s' could not be read as %s",
                source, stat.coercion_failures, spec.name, spec.type,
            )
            if spec.required:
                for idx in series.index[failed]:
                    reasons[idx].append(f"{spec.name}: not a valid {spec.type}")

        invalid = _validate(series, spec, stat)
        if invalid.any():
            log.warning(
                "Source '%s': %d value(s) in '%s' failed validation",
                source, int(invalid.sum()), spec.name,
            )
            for idx in series.index[invalid]:
                reasons[idx].append(f"{spec.name}: value outside allowed range/set")

        series, filled = _fill_missing(series, spec)
        stat.filled = filled
        if filled:
            log.info(
                "Source '%s': filled %d missing value(s) in '%s' using '%s'",
                source, filled, spec.name, spec.fill,
            )

        if spec.required:
            still_missing = series.isna() & ~failed
            for idx in series.index[still_missing]:
                reasons[idx].append(f"{spec.name}: required value is missing")

        working[spec.name] = series

    working = working[columns]
    rejected_mask = reasons.map(bool)

    rejects = working[rejected_mask].copy()
    if not rejects.empty:
        rejects[REJECT_REASON_COLUMN] = reasons[rejected_mask].map("; ".join)
        rejects[SOURCE_COLUMN] = source
    clean = working[~rejected_mask].copy()

    stats.rows_rejected = int(rejected_mask.sum())
    if stats.rows_rejected:
        log.warning(
            "Source '%s': quarantined %d of %d row(s)",
            source, stats.rows_rejected, stats.rows_in,
        )

    if schema.dedupe_on:
        before = len(clean)
        clean = clean.drop_duplicates(subset=schema.dedupe_on, keep="first")
        stats.duplicates_removed = before - len(clean)
        if stats.duplicates_removed:
            log.info(
                "Source '%s': removed %d duplicate row(s) on %s",
                source, stats.duplicates_removed, schema.dedupe_on,
            )

    clean = clean.reset_index(drop=True)
    stats.rows_out = len(clean)
    log.info(
        "Source '%s': %d row(s) in, %d clean, %d rejected, %d duplicate(s)",
        source, stats.rows_in, stats.rows_out, stats.rows_rejected, stats.duplicates_removed,
    )
    return CleanResult(clean, rejects.reset_index(drop=True), stats)
