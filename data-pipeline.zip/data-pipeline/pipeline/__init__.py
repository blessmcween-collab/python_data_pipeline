"""A small, config-driven data processing pipeline.

Read raw data (CSV, JSON or an HTTP API), clean and validate it against a
declared schema, apply declarative transforms, and write structured output
plus a run report.
"""

from .config import Config, ConfigError, load_config
from .pipeline import PipelineError, RunReport, run_pipeline

__version__ = "1.0.0"
__all__ = [
    "Config",
    "ConfigError",
    "load_config",
    "PipelineError",
    "RunReport",
    "run_pipeline",
]
