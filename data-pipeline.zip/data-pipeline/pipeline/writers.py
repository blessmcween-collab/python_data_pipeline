"""Output writers.

Writes are atomic: content goes to a temporary file in the same directory and
is then moved into place. A crash mid-write therefore leaves the previous
output intact rather than a half-written file that looks valid.
"""

from __future__ import annotations

import json
import os
import tempfile
from datetime import date, datetime
from pathlib import Path
from typing import Any

import pandas as pd

from .logging_setup import get_logger

log = get_logger("writers")


class WriterError(Exception):
    """Raised when an output cannot be written."""


def _json_default(value: Any) -> Any:
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, pd.Timestamp):
        return value.isoformat()
    if hasattr(value, "item"):
        try:
            return value.item()
        except (ValueError, AttributeError):
            pass
    return str(value)


def _atomic_write(path: Path, write_fn) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    handle, tmp_name = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    os.close(handle)
    tmp_path = Path(tmp_name)
    try:
        write_fn(tmp_path)
        tmp_path.replace(path)
    except Exception:
        tmp_path.unlink(missing_ok=True)
        raise


def _frame_to_records(frame: pd.DataFrame) -> list[dict]:
    """Convert to plain Python values so json.dump can handle everything."""
    safe = frame.astype(object).where(pd.notna(frame), None)
    return safe.to_dict(orient="records")


def write_dataframe(frame: pd.DataFrame, path: Path, fmt: str = "csv") -> Path:
    """Write ``frame`` to ``path`` in the requested format."""
    if frame is None:
        raise WriterError(f"nothing to write to {path}")
    if frame.empty:
        log.warning("Writing an empty dataset to %s (headers only)", path.name)

    try:
        if fmt == "csv":
            _atomic_write(path, lambda p: frame.to_csv(p, index=False, encoding="utf-8"))
        elif fmt == "json":
            def write_json(p: Path) -> None:
                p.write_text(
                    json.dumps(_frame_to_records(frame), indent=2, default=_json_default),
                    encoding="utf-8",
                )
            _atomic_write(path, write_json)
        elif fmt == "jsonl":
            def write_jsonl(p: Path) -> None:
                lines = [
                    json.dumps(record, default=_json_default)
                    for record in _frame_to_records(frame)
                ]
                p.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")
            _atomic_write(path, write_jsonl)
        else:  # pragma: no cover - guarded by config validation
            raise WriterError(f"unsupported output format '{fmt}'")
    except OSError as exc:
        raise WriterError(f"could not write {path}: {exc}") from exc

    log.info("Wrote %d row(s) to %s", len(frame), path.name)
    return path


def write_report(report: dict, path: Path) -> Path:
    """Write the machine-readable run summary."""
    try:
        _atomic_write(
            path,
            lambda p: p.write_text(
                json.dumps(report, indent=2, default=_json_default), encoding="utf-8"
            ),
        )
    except OSError as exc:
        raise WriterError(f"could not write report {path}: {exc}") from exc
    log.info("Wrote run report to %s", path.name)
    return path
