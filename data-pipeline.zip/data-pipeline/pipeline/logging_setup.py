"""Logging configuration.

Two handlers: a readable console stream for the person running the pipeline,
and a rotating file handler that keeps a fuller record (always DEBUG) for
working out what went wrong after the fact.
"""

from __future__ import annotations

import logging
import logging.handlers
from pathlib import Path

from .config import LoggingSpec

CONSOLE_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)-22s | %(message)s"
FILE_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)-22s | %(funcName)s:%(lineno)d | %(message)s"
DATE_FORMAT = "%H:%M:%S"


def setup_logging(spec: LoggingSpec, base_dir: Path | None = None) -> logging.Logger:
    """Configure the ``pipeline`` logger. Safe to call more than once."""
    logger = logging.getLogger("pipeline")
    logger.setLevel(logging.DEBUG)
    logger.propagate = False

    # Remove handlers from a previous call so repeated runs in one process
    # (tests, notebooks) don't duplicate every line.
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
        handler.close()

    console = logging.StreamHandler()
    console.setLevel(getattr(logging, spec.level))
    console.setFormatter(logging.Formatter(CONSOLE_FORMAT, datefmt=DATE_FORMAT))
    logger.addHandler(console)

    if spec.file:
        log_path = Path(spec.file)
        if not log_path.is_absolute() and base_dir is not None:
            log_path = base_dir / log_path
        try:
            log_path.parent.mkdir(parents=True, exist_ok=True)
            file_handler = logging.handlers.RotatingFileHandler(
                log_path,
                maxBytes=spec.max_bytes,
                backupCount=spec.backup_count,
                encoding="utf-8",
            )
            file_handler.setLevel(logging.DEBUG)
            file_handler.setFormatter(logging.Formatter(FILE_FORMAT))
            logger.addHandler(file_handler)
        except OSError as exc:
            # A read-only or missing directory shouldn't stop the run.
            logger.warning("File logging disabled (%s): %s", log_path, exc)

    return logger


def get_logger(name: str) -> logging.Logger:
    """Child logger under the configured ``pipeline`` root."""
    return logging.getLogger(f"pipeline.{name}")
