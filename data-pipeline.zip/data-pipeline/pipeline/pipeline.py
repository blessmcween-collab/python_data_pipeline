"""Orchestration.

Four stages: extract, clean, transform, load. Each source is independent, so
one unreadable file does not stop the others unless ``fail_fast`` is set. The
run finishes by writing a JSON report describing exactly what happened, which
is what you want when this is running unattended on a schedule.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd

from .cleaning import REJECT_REASON_COLUMN, SOURCE_COLUMN, clean_dataset
from .config import Config
from .logging_setup import get_logger
from .readers import ReaderError, read_source
from .transform import TransformError, apply_transforms
from .writers import WriterError, write_dataframe, write_report

log = get_logger("pipeline")


class PipelineError(Exception):
    """Raised when the run cannot sensibly continue."""


@dataclass
class RunReport:
    name: str
    started_at: str
    finished_at: str | None = None
    duration_seconds: float = 0.0
    status: str = "running"
    sources: dict[str, Any] = field(default_factory=dict)
    datasets: dict[str, int] = field(default_factory=dict)
    outputs: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "status": self.status,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "duration_seconds": round(self.duration_seconds, 3),
            "sources": self.sources,
            "datasets": self.datasets,
            "outputs": self.outputs,
            "warnings": self.warnings,
            "errors": self.errors,
        }


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def run_pipeline(config: Config, dry_run: bool = False) -> RunReport:
    """Execute the pipeline described by ``config``."""
    started = time.perf_counter()
    report = RunReport(name=config.run.name, started_at=_now())
    log.info("=" * 68)
    log.info("Starting pipeline '%s'%s", config.run.name, " (dry run)" if dry_run else "")

    datasets: dict[str, pd.DataFrame] = {}
    all_rejects: list[pd.DataFrame] = []

    # ---- extract + clean -------------------------------------------------
    for spec in config.sources:
        try:
            raw = read_source(spec, config.base_dir)
        except ReaderError as exc:
            message = f"source '{spec.name}': {exc}"
            report.errors.append(message)
            log.error("%s", message)
            if config.run.fail_fast:
                raise PipelineError(message) from exc
            continue

        result = clean_dataset(raw, spec.schema, spec.name)

        ratio = result.stats.reject_ratio
        if ratio > config.run.max_reject_ratio:
            message = (
                f"source '{spec.name}': rejected {ratio:.0%} of rows, above the "
                f"configured limit of {config.run.max_reject_ratio:.0%}"
            )
            report.errors.append(message)
            log.error("%s", message)
            if config.run.fail_fast:
                raise PipelineError(message)
        elif result.stats.rows_rejected:
            report.warnings.append(
                f"source '{spec.name}': {result.stats.rows_rejected} row(s) quarantined"
            )

        datasets[spec.name] = result.frame
        report.sources[spec.name] = result.stats.as_dict()
        if not result.rejects.empty:
            all_rejects.append(result.rejects)

    if not datasets:
        report.status = "failed"
        report.finished_at = _now()
        report.duration_seconds = time.perf_counter() - started
        raise PipelineError("no sources could be read; nothing to process")

    # ---- transform -------------------------------------------------------
    if config.transforms:
        try:
            datasets = apply_transforms(datasets, config.transforms, config.run.fail_fast)
        except TransformError as exc:
            report.errors.append(str(exc))
            log.error("Transform stage failed: %s", exc)
            if config.run.fail_fast:
                report.status = "failed"
                report.finished_at = _now()
                raise PipelineError(str(exc)) from exc
    else:
        log.info("No transforms configured; skipping transform stage")

    report.datasets = {name: len(frame) for name, frame in datasets.items()}

    # ---- load ------------------------------------------------------------
    if dry_run:
        log.info("Dry run: skipping all writes")
        for spec in config.outputs:
            if spec.dataset not in datasets:
                report.warnings.append(f"output references unknown dataset '{spec.dataset}'")
        report.status = "dry-run"
    else:
        output_dir = config.output_dir
        output_dir.mkdir(parents=True, exist_ok=True)

        for spec in config.outputs:
            if spec.dataset not in datasets:
                message = (
                    f"output '{spec.filename}': no dataset named '{spec.dataset}' "
                    f"(available: {sorted(datasets)})"
                )
                report.errors.append(message)
                log.error("%s", message)
                continue
            try:
                path = write_dataframe(datasets[spec.dataset], output_dir / spec.filename, spec.format)
                report.outputs.append(str(path.relative_to(config.base_dir)) if path.is_relative_to(config.base_dir) else str(path))
            except WriterError as exc:
                report.errors.append(str(exc))
                log.error("%s", exc)
                if config.run.fail_fast:
                    raise PipelineError(str(exc)) from exc

        if config.run.quarantine_rejects and all_rejects:
            rejects = pd.concat(all_rejects, ignore_index=True, sort=False)
            leading = [SOURCE_COLUMN, REJECT_REASON_COLUMN]
            rest = [c for c in rejects.columns if c not in leading]
            rejects = rejects[[*leading, *rest]]
            try:
                path = write_dataframe(rejects, output_dir / "rejected_rows.csv", "csv")
                report.outputs.append(path.name)
            except WriterError as exc:
                report.errors.append(str(exc))

    report.duration_seconds = time.perf_counter() - started
    report.finished_at = _now()
    if report.status == "running":
        report.status = "completed_with_errors" if report.errors else "completed"

    if not dry_run:
        try:
            write_report(report.as_dict(), config.output_dir / "run_report.json")
        except WriterError as exc:
            log.error("Could not write run report: %s", exc)

    log.info(
        "Pipeline '%s' %s in %.2fs (%d dataset(s), %d output(s), %d error(s))",
        config.run.name, report.status, report.duration_seconds,
        len(report.datasets), len(report.outputs), len(report.errors),
    )
    log.info("=" * 68)
    return report
