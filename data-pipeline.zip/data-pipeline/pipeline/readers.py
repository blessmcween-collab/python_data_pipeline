"""Input readers.

Each reader returns a raw ``pandas.DataFrame`` with normalised column names
and no other processing. Anything to do with types, nulls or validation
belongs in :mod:`pipeline.cleaning`, which keeps the readers easy to reason
about and to test.
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any

import pandas as pd

from .config import SourceSpec
from .logging_setup import get_logger

log = get_logger("readers")

ENCODING_FALLBACKS = ["utf-8-sig", "utf-8", "cp1252", "latin-1"]


class ReaderError(Exception):
    """Raised when a source cannot be read at all."""


def normalize_column_name(name: Any) -> str:
    """``"  Customer ID "`` -> ``"customer_id"``. Safe on non-string headers."""
    text = str(name).strip().lower()
    cleaned = []
    for char in text:
        cleaned.append(char if char.isalnum() else "_")
    collapsed = "_".join(part for part in "".join(cleaned).split("_") if part)
    return collapsed or "unnamed"


def _normalize_frame_columns(frame: pd.DataFrame, source: str) -> pd.DataFrame:
    frame = frame.copy()
    original = list(frame.columns)
    frame.columns = [normalize_column_name(c) for c in original]

    seen: dict[str, int] = {}
    deduped = []
    for col in frame.columns:
        if col in seen:
            seen[col] += 1
            new_name = f"{col}_{seen[col]}"
            log.warning(
                "Source '%s': duplicate column '%s' renamed to '%s'", source, col, new_name
            )
            deduped.append(new_name)
        else:
            seen[col] = 0
            deduped.append(col)
    frame.columns = deduped

    renamed = {o: n for o, n in zip(original, deduped) if str(o) != n}
    if renamed:
        log.debug("Source '%s': normalised headers %s", source, renamed)
    return frame


def _read_text(path: Path, encoding_hint: str | None = None) -> str:
    """Read a text file, trying a few encodings before giving up."""
    candidates = [encoding_hint, *ENCODING_FALLBACKS] if encoding_hint else ENCODING_FALLBACKS
    last_error: Exception | None = None
    for encoding in candidates:
        if encoding is None:
            continue
        try:
            return path.read_text(encoding=encoding)
        except UnicodeDecodeError as exc:
            last_error = exc
            log.debug("Failed to decode %s as %s", path, encoding)
    raise ReaderError(f"could not decode {path} with any of {candidates}: {last_error}")


def read_csv(spec: SourceSpec, base_dir: Path) -> pd.DataFrame:
    path = base_dir / spec.path if not Path(spec.path).is_absolute() else Path(spec.path)
    if not path.exists():
        raise ReaderError(f"source '{spec.name}': file not found at {path}")
    if path.stat().st_size == 0:
        log.warning("Source '%s': file %s is empty", spec.name, path)
        return pd.DataFrame()

    options = dict(spec.options)
    encoding = options.pop("encoding", None)
    delimiter = options.pop("delimiter", None) or options.pop("sep", None)

    read_kwargs: dict[str, Any] = {
        "dtype": str,          # read everything as text; cleaning does the casting
        "keep_default_na": False,  # we handle null tokens ourselves, consistently
        "skipinitialspace": True,
        "on_bad_lines": "warn",
    }
    if delimiter:
        read_kwargs["sep"] = delimiter
    read_kwargs.update(options)

    last_error: Exception | None = None
    for candidate in ([encoding] if encoding else []) + ENCODING_FALLBACKS:
        try:
            frame = pd.read_csv(path, encoding=candidate, **read_kwargs)
            break
        except UnicodeDecodeError as exc:
            last_error = exc
            continue
        except pd.errors.EmptyDataError:
            log.warning("Source '%s': %s has no parsable rows", spec.name, path)
            return pd.DataFrame()
        except pd.errors.ParserError as exc:
            raise ReaderError(f"source '{spec.name}': malformed CSV in {path}: {exc}") from exc
    else:
        raise ReaderError(f"source '{spec.name}': could not decode {path}: {last_error}")

    log.info("Source '%s': read %d row(s) from %s", spec.name, len(frame), path.name)
    return _normalize_frame_columns(frame, spec.name)


def _parse_json_text(text: str, source: str) -> Any:
    """Parse a JSON document, falling back to newline-delimited JSON."""
    stripped = text.strip()
    if not stripped:
        return []
    try:
        return json.loads(stripped)
    except json.JSONDecodeError as exc:
        records = []
        for lineno, line in enumerate(stripped.splitlines(), start=1):
            line = line.strip().rstrip(",")
            if not line:
                continue
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError:
                raise ReaderError(
                    f"source '{source}': invalid JSON (and not valid NDJSON either); "
                    f"first failure at line {lineno}: {exc.msg}"
                ) from exc
        log.info("Source '%s': parsed as newline-delimited JSON", source)
        return records


def _extract_records(payload: Any, record_path: str | None, source: str) -> list[dict]:
    """Drill into the payload to find the list of records."""
    node = payload
    if record_path:
        for part in record_path.split("."):
            if isinstance(node, dict) and part in node:
                node = node[part]
            else:
                raise ReaderError(
                    f"source '{source}': record_path '{record_path}' not found in payload"
                )
    if isinstance(node, dict):
        # A single object, or a wrapper like {"data": [...]} we can spot ourselves.
        for key in ("data", "records", "results", "items", "rows"):
            if isinstance(node.get(key), list):
                log.debug("Source '%s': using records under key '%s'", source, key)
                return node[key]
        return [node]
    if isinstance(node, list):
        return [r for r in node if isinstance(r, dict)]
    raise ReaderError(f"source '{source}': expected a list or object of records, got {type(node).__name__}")


def read_json(spec: SourceSpec, base_dir: Path) -> pd.DataFrame:
    path = base_dir / spec.path if not Path(spec.path).is_absolute() else Path(spec.path)
    if not path.exists():
        raise ReaderError(f"source '{spec.name}': file not found at {path}")

    text = _read_text(path, spec.options.get("encoding"))
    payload = _parse_json_text(text, spec.name)
    records = _extract_records(payload, spec.options.get("record_path"), spec.name)

    if not records:
        log.warning("Source '%s': no records found in %s", spec.name, path)
        return pd.DataFrame()

    # json_normalize flattens nested objects into dotted column names.
    frame = pd.json_normalize(records, sep="_")
    frame = frame.astype(object).where(pd.notna(frame), None)
    log.info("Source '%s': read %d record(s) from %s", spec.name, len(frame), path.name)
    return _normalize_frame_columns(frame, spec.name)


def read_api(spec: SourceSpec, base_dir: Path) -> pd.DataFrame:
    """Fetch records over HTTP with retries, backoff and optional pagination.

    Credentials are never stored in the config. Set ``auth_env`` to the *name*
    of an environment variable holding the token.
    """
    try:
        import requests
    except ImportError as exc:  # pragma: no cover - depends on install extras
        raise ReaderError(
            f"source '{spec.name}': type 'api' needs the 'requests' package "
            "(pip install requests)"
        ) from exc

    options = spec.options
    timeout = float(options.get("timeout", 15))
    max_retries = int(options.get("max_retries", 3))
    backoff = float(options.get("backoff_seconds", 1.0))
    max_pages = int(options.get("max_pages", 1))
    page_param = options.get("page_param", "page")
    params = dict(options.get("params", {}) or {})

    headers = {"Accept": "application/json", **(options.get("headers", {}) or {})}
    auth_env = options.get("auth_env")
    if auth_env:
        token = os.environ.get(auth_env)
        if not token:
            raise ReaderError(
                f"source '{spec.name}': environment variable '{auth_env}' is not set"
            )
        headers["Authorization"] = f"Bearer {token}"

    all_records: list[dict] = []
    for page in range(1, max_pages + 1):
        if max_pages > 1:
            params[page_param] = page

        payload = None
        for attempt in range(1, max_retries + 1):
            try:
                response = requests.get(
                    spec.url, params=params, headers=headers, timeout=timeout
                )
                if response.status_code == 429 or response.status_code >= 500:
                    raise requests.HTTPError(
                        f"retryable status {response.status_code}", response=response
                    )
                response.raise_for_status()
                payload = response.json()
                break
            except (requests.RequestException, ValueError) as exc:
                if attempt == max_retries:
                    raise ReaderError(
                        f"source '{spec.name}': request to {spec.url} failed after "
                        f"{max_retries} attempt(s): {exc}"
                    ) from exc
                wait = backoff * (2 ** (attempt - 1))
                log.warning(
                    "Source '%s': attempt %d/%d failed (%s); retrying in %.1fs",
                    spec.name, attempt, max_retries, exc, wait,
                )
                time.sleep(wait)

        records = _extract_records(payload, options.get("record_path"), spec.name)
        if not records:
            log.info("Source '%s': page %d returned no records; stopping", spec.name, page)
            break
        all_records.extend(records)

    if not all_records:
        log.warning("Source '%s': API returned no records", spec.name)
        return pd.DataFrame()

    frame = pd.json_normalize(all_records, sep="_")
    log.info("Source '%s': fetched %d record(s) from API", spec.name, len(frame))
    return _normalize_frame_columns(frame, spec.name)


READERS = {"csv": read_csv, "json": read_json, "api": read_api}


def read_source(spec: SourceSpec, base_dir: Path) -> pd.DataFrame:
    """Dispatch to the reader matching ``spec.type``."""
    reader = READERS[spec.type]
    log.debug("Reading source '%s' (type=%s)", spec.name, spec.type)
    return reader(spec, base_dir)
