"""Configuration management.

The whole pipeline is driven by a single YAML file. This module parses that
file into typed dataclasses and validates it *before* any data is touched, so
a typo in the config fails immediately with a clear message rather than
halfway through a long run.

Any value can be overridden from the environment using the ``PIPELINE__``
prefix and ``__`` as a path separator, e.g.::

    PIPELINE__LOGGING__LEVEL=DEBUG
    PIPELINE__PIPELINE__OUTPUT_DIR=/tmp/out
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

ENV_PREFIX = "PIPELINE__"
ENV_SEPARATOR = "__"

VALID_TYPES = {"string", "integer", "float", "boolean", "date", "datetime", "category"}
VALID_FILL = {"none", "default", "mean", "median", "mode", "zero", "empty", "ffill"}
VALID_TRANSFORMS = {
    "strip",
    "lower",
    "upper",
    "title",
    "collapse_spaces",
    "strip_currency",
    "digits_only",
}
VALID_SOURCE_TYPES = {"csv", "json", "api"}
VALID_FORMATS = {"csv", "json", "jsonl"}

DEFAULT_NULL_TOKENS = ["", "na", "n/a", "null", "none", "nil", "-", "--", "?", "unknown"]


class ConfigError(Exception):
    """Raised when the configuration file is malformed or internally inconsistent."""


@dataclass
class FieldSpec:
    """Declares how one column should be named, typed, cleaned and validated."""

    name: str
    source_name: str | None = None
    type: str = "string"
    required: bool = False
    default: Any = None
    fill: str = "none"
    transform: list[str] = field(default_factory=list)
    allowed: list[Any] | None = None
    min: float | None = None
    max: float | None = None
    date_format: str | None = None

    def __post_init__(self) -> None:
        if self.type not in VALID_TYPES:
            raise ConfigError(
                f"field '{self.name}': unknown type '{self.type}'. "
                f"Expected one of {sorted(VALID_TYPES)}"
            )
        if self.fill not in VALID_FILL:
            raise ConfigError(
                f"field '{self.name}': unknown fill strategy '{self.fill}'. "
                f"Expected one of {sorted(VALID_FILL)}"
            )
        bad = set(self.transform) - VALID_TRANSFORMS
        if bad:
            raise ConfigError(
                f"field '{self.name}': unknown transform(s) {sorted(bad)}. "
                f"Expected any of {sorted(VALID_TRANSFORMS)}"
            )
        if self.fill == "default" and self.default is None:
            raise ConfigError(
                f"field '{self.name}': fill='default' requires a 'default' value"
            )
        if self.fill in {"mean", "median"} and self.type not in {"integer", "float"}:
            raise ConfigError(
                f"field '{self.name}': fill='{self.fill}' only applies to numeric types"
            )
        if self.min is not None and self.max is not None and self.min > self.max:
            raise ConfigError(f"field '{self.name}': min is greater than max")

    @property
    def input_name(self) -> str:
        """Column name expected in the raw data (after header normalisation)."""
        return self.source_name or self.name


@dataclass
class SchemaSpec:
    fields: list[FieldSpec]
    dedupe_on: list[str] = field(default_factory=list)
    null_tokens: list[str] = field(default_factory=lambda: list(DEFAULT_NULL_TOKENS))
    drop_unknown_columns: bool = True

    def __post_init__(self) -> None:
        if not self.fields:
            raise ConfigError("schema must declare at least one field")
        names = [f.name for f in self.fields]
        dupes = {n for n in names if names.count(n) > 1}
        if dupes:
            raise ConfigError(f"duplicate field names in schema: {sorted(dupes)}")
        unknown = set(self.dedupe_on) - set(names)
        if unknown:
            raise ConfigError(f"dedupe_on refers to undeclared fields: {sorted(unknown)}")
        self.null_tokens = [str(t).strip().lower() for t in self.null_tokens]


@dataclass
class SourceSpec:
    name: str
    type: str
    schema: SchemaSpec
    path: str | None = None
    url: str | None = None
    options: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.type not in VALID_SOURCE_TYPES:
            raise ConfigError(
                f"source '{self.name}': unknown type '{self.type}'. "
                f"Expected one of {sorted(VALID_SOURCE_TYPES)}"
            )
        if self.type in {"csv", "json"} and not self.path:
            raise ConfigError(f"source '{self.name}': type '{self.type}' requires 'path'")
        if self.type == "api" and not self.url:
            raise ConfigError(f"source '{self.name}': type 'api' requires 'url'")


@dataclass
class OutputSpec:
    dataset: str
    filename: str
    format: str = "csv"

    def __post_init__(self) -> None:
        if self.format not in VALID_FORMATS:
            raise ConfigError(
                f"output '{self.filename}': unknown format '{self.format}'. "
                f"Expected one of {sorted(VALID_FORMATS)}"
            )


@dataclass
class LoggingSpec:
    level: str = "INFO"
    file: str | None = "logs/pipeline.log"
    max_bytes: int = 1_048_576
    backup_count: int = 3

    def __post_init__(self) -> None:
        self.level = str(self.level).upper()
        valid = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        if self.level not in valid:
            raise ConfigError(f"logging.level must be one of {sorted(valid)}")


@dataclass
class RunSpec:
    name: str = "pipeline"
    output_dir: str = "data/output"
    quarantine_rejects: bool = True
    max_reject_ratio: float = 1.0
    fail_fast: bool = False

    def __post_init__(self) -> None:
        if not 0.0 <= self.max_reject_ratio <= 1.0:
            raise ConfigError("pipeline.max_reject_ratio must be between 0 and 1")


@dataclass
class Config:
    run: RunSpec
    logging: LoggingSpec
    sources: list[SourceSpec]
    transforms: list[dict[str, Any]]
    outputs: list[OutputSpec]
    base_dir: Path = Path(".")

    def resolve(self, path: str | Path) -> Path:
        """Resolve a config-relative path against the config file's directory."""
        p = Path(path)
        return p if p.is_absolute() else (self.base_dir / p)

    @property
    def output_dir(self) -> Path:
        return self.resolve(self.run.output_dir)


def _coerce_env_value(raw: str) -> Any:
    """Turn an environment string into a bool/int/float/None where it obviously is one."""
    lowered = raw.strip().lower()
    if lowered in {"true", "yes"}:
        return True
    if lowered in {"false", "no"}:
        return False
    if lowered in {"none", "null"}:
        return None
    for caster in (int, float):
        try:
            return caster(raw)
        except ValueError:
            continue
    return raw


def apply_env_overrides(data: dict[str, Any], environ: dict[str, str] | None = None) -> list[str]:
    """Mutate ``data`` in place with any ``PIPELINE__*`` overrides. Returns keys applied."""
    environ = os.environ if environ is None else environ
    applied: list[str] = []
    for key, raw in environ.items():
        if not key.startswith(ENV_PREFIX):
            continue
        path = key[len(ENV_PREFIX) :].lower().split(ENV_SEPARATOR)
        if not path or not path[0]:
            continue
        cursor: Any = data
        for part in path[:-1]:
            if not isinstance(cursor.get(part), dict):
                cursor[part] = {}
            cursor = cursor[part]
        if isinstance(cursor, dict):
            cursor[path[-1]] = _coerce_env_value(raw)
            applied.append(key)
    return applied


def _build_schema(raw: dict[str, Any], source_name: str) -> SchemaSpec:
    if not isinstance(raw, dict):
        raise ConfigError(f"source '{source_name}': 'schema' must be a mapping")
    fields_raw = raw.get("fields") or []
    if not isinstance(fields_raw, list):
        raise ConfigError(f"source '{source_name}': 'schema.fields' must be a list")
    specs = []
    for item in fields_raw:
        if not isinstance(item, dict) or "name" not in item:
            raise ConfigError(f"source '{source_name}': every field needs a 'name'")
        known = {f.name for f in (FieldSpec.__dataclass_fields__.values())}
        unknown = set(item) - known
        if unknown:
            raise ConfigError(
                f"source '{source_name}', field '{item['name']}': "
                f"unknown key(s) {sorted(unknown)}"
            )
        specs.append(FieldSpec(**item))
    return SchemaSpec(
        fields=specs,
        dedupe_on=raw.get("dedupe_on", []),
        null_tokens=raw.get("null_tokens", list(DEFAULT_NULL_TOKENS)),
        drop_unknown_columns=raw.get("drop_unknown_columns", True),
    )


def load_config(path: str | Path, environ: dict[str, str] | None = None) -> Config:
    """Read, override and validate the YAML config at ``path``."""
    config_path = Path(path)
    if not config_path.exists():
        raise ConfigError(f"config file not found: {config_path}")

    try:
        raw = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as exc:
        raise ConfigError(f"could not parse YAML in {config_path}: {exc}") from exc

    if not isinstance(raw, dict):
        raise ConfigError(f"{config_path}: top level of the config must be a mapping")

    apply_env_overrides(raw, environ)

    sources_raw = raw.get("sources") or []
    if not isinstance(sources_raw, list) or not sources_raw:
        raise ConfigError("config must declare at least one entry under 'sources'")

    sources = []
    for item in sources_raw:
        if not isinstance(item, dict) or "name" not in item:
            raise ConfigError("every source needs a 'name'")
        sources.append(
            SourceSpec(
                name=item["name"],
                type=item.get("type", "csv"),
                path=item.get("path"),
                url=item.get("url"),
                options=item.get("options", {}) or {},
                schema=_build_schema(item.get("schema", {}), item["name"]),
            )
        )

    names = [s.name for s in sources]
    dupes = {n for n in names if names.count(n) > 1}
    if dupes:
        raise ConfigError(f"duplicate source names: {sorted(dupes)}")

    outputs = [OutputSpec(**o) for o in (raw.get("outputs") or [])]
    if not outputs:
        raise ConfigError("config must declare at least one entry under 'outputs'")

    return Config(
        run=RunSpec(**(raw.get("pipeline") or {})),
        logging=LoggingSpec(**(raw.get("logging") or {})),
        sources=sources,
        transforms=raw.get("transforms") or [],
        outputs=outputs,
        base_dir=config_path.parent.resolve(),
    )
