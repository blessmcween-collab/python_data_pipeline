"""Transform stage.

Transforms are declared in the config as a list of small, named operations
that run in order. Each one reads named datasets and writes a named dataset
back, so a later step can build on an earlier one.

Deliberately *not* supported: arbitrary Python expressions from the config.
Evaluating config-supplied code would mean anyone who can edit the YAML can
run anything, so the operations below are a fixed, auditable set instead.
"""

from __future__ import annotations

import operator
from typing import Any, Callable

import pandas as pd

from .logging_setup import get_logger

log = get_logger("transform")

ARITHMETIC_OPS: dict[str, Callable[[Any, Any], Any]] = {
    "+": operator.add,
    "-": operator.sub,
    "*": operator.mul,
    "/": operator.truediv,
}

COMPARISON_OPS: dict[str, Callable[[Any, Any], Any]] = {
    "==": operator.eq,
    "!=": operator.ne,
    ">": operator.gt,
    ">=": operator.ge,
    "<": operator.lt,
    "<=": operator.le,
}

DATE_PARTS = {
    "year": lambda s: s.dt.year,
    "month": lambda s: s.dt.month,
    "day": lambda s: s.dt.day,
    "quarter": lambda s: s.dt.quarter,
    "weekday": lambda s: s.dt.day_name(),
    "month_name": lambda s: s.dt.month_name(),
    "iso_week": lambda s: s.dt.isocalendar().week.astype("Int64"),
    "year_month": lambda s: s.dt.strftime("%Y-%m"),
}

AGGREGATION_FUNCS = {
    "sum", "mean", "median", "min", "max", "count", "nunique", "first", "last", "std",
}


class TransformError(Exception):
    """Raised when a transform is misconfigured or refers to something missing."""


def _require(step: dict, key: str, index: int) -> Any:
    if key not in step:
        raise TransformError(f"transform #{index} ({step.get('type')}): missing '{key}'")
    return step[key]


def _get_dataset(datasets: dict[str, pd.DataFrame], name: str, index: int) -> pd.DataFrame:
    if name not in datasets:
        raise TransformError(
            f"transform #{index}: no dataset named '{name}'. "
            f"Available: {sorted(datasets)}"
        )
    return datasets[name]


def _require_columns(frame: pd.DataFrame, columns: list[str], dataset: str, index: int) -> None:
    missing = [c for c in columns if c not in frame.columns]
    if missing:
        raise TransformError(
            f"transform #{index}: dataset '{dataset}' has no column(s) {missing}. "
            f"Available: {sorted(frame.columns)}"
        )


def _op_join(datasets: dict[str, pd.DataFrame], step: dict, index: int) -> tuple[str, pd.DataFrame]:
    left_name = _require(step, "left", index)
    right_name = _require(step, "right", index)
    left = _get_dataset(datasets, left_name, index)
    right = _get_dataset(datasets, right_name, index)

    left_on = _require(step, "left_on", index)
    right_on = step.get("right_on", left_on)
    how = step.get("how", "left")
    if how not in {"left", "right", "inner", "outer"}:
        raise TransformError(f"transform #{index}: unsupported join type '{how}'")

    _require_columns(left, [left_on], left_name, index)
    _require_columns(right, [right_on], right_name, index)

    # Align key dtypes so an Int64 key and a string key still match up.
    left = left.copy()
    right = right.copy()
    if left[left_on].dtype != right[right_on].dtype:
        log.debug(
            "transform #%d: casting join keys to string (%s vs %s)",
            index, left[left_on].dtype, right[right_on].dtype,
        )
        left[left_on] = left[left_on].astype("string")
        right[right_on] = right[right_on].astype("string")

    merged = left.merge(
        right, left_on=left_on, right_on=right_on, how=how, suffixes=("", f"_{right_name}")
    )
    unmatched = int(merged[right_on].isna().sum()) if how == "left" else 0
    if unmatched:
        log.warning(
            "transform #%d: %d row(s) in '%s' had no match in '%s'",
            index, unmatched, left_name, right_name,
        )
    name = step.get("name", f"{left_name}_{right_name}")
    log.info(
        "transform #%d: joined '%s' (%d) with '%s' (%d) -> '%s' (%d row(s))",
        index, left_name, len(left), right_name, len(right), name, len(merged),
    )
    return name, merged


def _resolve_operand(frame: pd.DataFrame, value: Any) -> Any:
    """A string naming a column resolves to that column; anything else is a literal."""
    if isinstance(value, str) and value in frame.columns:
        return pd.to_numeric(frame[value], errors="coerce")
    return value


def _op_derive_arithmetic(
    datasets: dict[str, pd.DataFrame], step: dict, index: int
) -> tuple[str, pd.DataFrame]:
    dataset = _require(step, "dataset", index)
    frame = _get_dataset(datasets, dataset, index).copy()
    target = _require(step, "target", index)
    op_symbol = _require(step, "op", index)
    if op_symbol not in ARITHMETIC_OPS:
        raise TransformError(
            f"transform #{index}: unsupported operator '{op_symbol}'. "
            f"Expected one of {sorted(ARITHMETIC_OPS)}"
        )

    left = _resolve_operand(frame, _require(step, "left", index))
    right = _resolve_operand(frame, _require(step, "right", index))

    if op_symbol == "/":
        right_safe = right.replace(0, pd.NA) if isinstance(right, pd.Series) else (right or pd.NA)
        result = ARITHMETIC_OPS[op_symbol](left, right_safe)
    else:
        result = ARITHMETIC_OPS[op_symbol](left, right)

    if "round" in step and isinstance(result, pd.Series):
        result = result.round(int(step["round"]))

    frame[target] = result
    nulls = int(pd.isna(frame[target]).sum())
    if nulls:
        log.debug("transform #%d: '%s' is null for %d row(s)", index, target, nulls)
    log.info("transform #%d: derived '%s' on dataset '%s'", index, target, dataset)
    return step.get("name", dataset), frame


def _op_derive_date_part(
    datasets: dict[str, pd.DataFrame], step: dict, index: int
) -> tuple[str, pd.DataFrame]:
    dataset = _require(step, "dataset", index)
    frame = _get_dataset(datasets, dataset, index).copy()
    source = _require(step, "source", index)
    part = _require(step, "part", index)
    target = step.get("target", f"{source}_{part}")

    _require_columns(frame, [source], dataset, index)
    if part not in DATE_PARTS:
        raise TransformError(
            f"transform #{index}: unknown date part '{part}'. Expected one of {sorted(DATE_PARTS)}"
        )

    series = pd.to_datetime(frame[source], errors="coerce")
    frame[target] = DATE_PARTS[part](series)
    log.info("transform #%d: derived '%s' from '%s'", index, target, source)
    return step.get("name", dataset), frame


def _op_map_values(
    datasets: dict[str, pd.DataFrame], step: dict, index: int
) -> tuple[str, pd.DataFrame]:
    dataset = _require(step, "dataset", index)
    frame = _get_dataset(datasets, dataset, index).copy()
    source = _require(step, "source", index)
    mapping = _require(step, "mapping", index)
    target = step.get("target", source)
    default = step.get("default")

    _require_columns(frame, [source], dataset, index)
    if not isinstance(mapping, dict):
        raise TransformError(f"transform #{index}: 'mapping' must be a mapping of value -> value")

    lookup = {str(k).strip().lower(): v for k, v in mapping.items()}

    def convert(value: Any) -> Any:
        if pd.isna(value):
            return default
        return lookup.get(str(value).strip().lower(), default if default is not None else value)

    frame[target] = frame[source].map(convert)
    log.info("transform #%d: mapped '%s' -> '%s'", index, source, target)
    return step.get("name", dataset), frame


def _op_filter_rows(
    datasets: dict[str, pd.DataFrame], step: dict, index: int
) -> tuple[str, pd.DataFrame]:
    dataset = _require(step, "dataset", index)
    frame = _get_dataset(datasets, dataset, index)
    column = _require(step, "column", index)
    op_symbol = _require(step, "op", index)
    value = step.get("value")

    _require_columns(frame, [column], dataset, index)
    if op_symbol in COMPARISON_OPS:
        target_series = frame[column]
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            target_series = pd.to_numeric(target_series, errors="coerce")
        mask = COMPARISON_OPS[op_symbol](target_series, value).fillna(False)
    elif op_symbol == "in":
        mask = frame[column].isin(value or [])
    elif op_symbol == "not_null":
        mask = frame[column].notna()
    else:
        raise TransformError(
            f"transform #{index}: unsupported filter operator '{op_symbol}'. "
            f"Expected one of {sorted(COMPARISON_OPS) + ['in', 'not_null']}"
        )

    filtered = frame[mask.astype(bool)].reset_index(drop=True)
    log.info(
        "transform #%d: filter on '%s' kept %d of %d row(s)",
        index, column, len(filtered), len(frame),
    )
    return step.get("name", dataset), filtered


def _op_aggregate(
    datasets: dict[str, pd.DataFrame], step: dict, index: int
) -> tuple[str, pd.DataFrame]:
    dataset = _require(step, "dataset", index)
    frame = _get_dataset(datasets, dataset, index)
    group_by = _require(step, "group_by", index)
    aggregations = _require(step, "aggregations", index)
    name = step.get("name", f"{dataset}_agg")

    if isinstance(group_by, str):
        group_by = [group_by]
    _require_columns(frame, group_by, dataset, index)

    if frame.empty:
        log.warning("transform #%d: dataset '%s' is empty; aggregation skipped", index, dataset)
        return name, pd.DataFrame(columns=[*group_by, *(a.get("target", a["column"]) for a in aggregations)])

    spec: dict[str, tuple[str, str]] = {}
    for agg in aggregations:
        column = agg.get("column")
        func = agg.get("func")
        if not column or not func:
            raise TransformError(f"transform #{index}: each aggregation needs 'column' and 'func'")
        if func not in AGGREGATION_FUNCS:
            raise TransformError(
                f"transform #{index}: unsupported aggregation '{func}'. "
                f"Expected one of {sorted(AGGREGATION_FUNCS)}"
            )
        _require_columns(frame, [column], dataset, index)
        spec[agg.get("target", f"{column}_{func}")] = (column, func)

    grouped = frame.groupby(group_by, dropna=False, observed=True).agg(**spec).reset_index()

    for agg in aggregations:
        target = agg.get("target", f"{agg['column']}_{agg['func']}")
        if "round" in agg and target in grouped.columns:
            grouped[target] = pd.to_numeric(grouped[target], errors="coerce").round(int(agg["round"]))

    if step.get("sort_by"):
        sort_by = step["sort_by"]
        sort_by = [sort_by] if isinstance(sort_by, str) else sort_by
        _require_columns(grouped, sort_by, name, index)
        grouped = grouped.sort_values(sort_by, ascending=step.get("ascending", False))
        grouped = grouped.reset_index(drop=True)

    log.info(
        "transform #%d: aggregated '%s' into '%s' (%d group(s))",
        index, dataset, name, len(grouped),
    )
    return name, grouped


OPERATIONS = {
    "join": _op_join,
    "derive_arithmetic": _op_derive_arithmetic,
    "derive_date_part": _op_derive_date_part,
    "map_values": _op_map_values,
    "filter_rows": _op_filter_rows,
    "aggregate": _op_aggregate,
}


def apply_transforms(
    datasets: dict[str, pd.DataFrame], steps: list[dict], fail_fast: bool = False
) -> dict[str, pd.DataFrame]:
    """Run each step in order, returning the updated dataset collection."""
    result = dict(datasets)
    for index, step in enumerate(steps, start=1):
        if not isinstance(step, dict) or "type" not in step:
            raise TransformError(f"transform #{index}: every transform needs a 'type'")
        kind = step["type"]
        if kind not in OPERATIONS:
            raise TransformError(
                f"transform #{index}: unknown type '{kind}'. Expected one of {sorted(OPERATIONS)}"
            )
        try:
            name, frame = OPERATIONS[kind](result, step, index)
            result[name] = frame
        except TransformError:
            raise
        except Exception as exc:
            message = f"transform #{index} ({kind}) failed: {exc}"
            if fail_fast:
                raise TransformError(message) from exc
            log.error("%s - continuing with the datasets built so far", message)
    return result
