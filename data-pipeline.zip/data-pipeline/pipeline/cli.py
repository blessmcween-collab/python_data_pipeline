"""Command line entry point.

Usage::

    python -m pipeline --config config.yaml
    python -m pipeline --config config.yaml --dry-run --log-level DEBUG
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .config import ConfigError, load_config
from .logging_setup import setup_logging
from .pipeline import PipelineError, run_pipeline

EXIT_OK = 0
EXIT_COMPLETED_WITH_ERRORS = 1
EXIT_FAILED = 2
EXIT_BAD_CONFIG = 3


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pipeline",
        description="Read raw CSV/JSON/API data, clean it, transform it and write structured output.",
        epilog="Any config value can be overridden with PIPELINE__SECTION__KEY environment variables.",
    )
    parser.add_argument(
        "-c", "--config", default="config.yaml",
        help="path to the YAML config file (default: config.yaml)",
    )
    parser.add_argument(
        "-o", "--output-dir", default=None,
        help="override pipeline.output_dir from the config",
    )
    parser.add_argument(
        "-l", "--log-level", default=None,
        choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        help="override logging.level from the config",
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="run every stage but write nothing to disk",
    )
    parser.add_argument(
        "--fail-fast", action="store_true",
        help="stop at the first error instead of carrying on",
    )
    parser.add_argument(
        "--quiet", action="store_true",
        help="only print the final summary line",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    try:
        config = load_config(args.config)
    except ConfigError as exc:
        print(f"Configuration error: {exc}", file=sys.stderr)
        return EXIT_BAD_CONFIG

    if args.log_level:
        config.logging.level = args.log_level
    if args.quiet:
        config.logging.level = "ERROR"
    if args.output_dir:
        config.run.output_dir = args.output_dir
    if args.fail_fast:
        config.run.fail_fast = True

    setup_logging(config.logging, config.base_dir)

    try:
        report = run_pipeline(config, dry_run=args.dry_run)
    except PipelineError as exc:
        print(f"Pipeline failed: {exc}", file=sys.stderr)
        return EXIT_FAILED
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        return EXIT_FAILED

    rows = sum(report.datasets.values())
    print(
        f"{report.name}: {report.status} - {len(report.datasets)} dataset(s), "
        f"{rows} row(s), {len(report.outputs)} file(s) written in "
        f"{report.duration_seconds:.2f}s"
    )
    for warning in report.warnings:
        print(f"  warning: {warning}")
    for error in report.errors:
        print(f"  error:   {error}", file=sys.stderr)

    if report.errors:
        return EXIT_COMPLETED_WITH_ERRORS
    return EXIT_OK


if __name__ == "__main__":
    raise SystemExit(main())
